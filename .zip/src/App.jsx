import React from 'react';

const App = () => {
  return (
    <div>
      <h1 className='text-6xl text-center'> Fresh Harvests Project Setup</h1>
    </div>
  );
};

export default App;